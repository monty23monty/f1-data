#
# Kudos for Hunter Vaners for creating the 
# AC App Templaee.
#
# Kudos also to the many other developers of
# the AC plugins available at RaceDepartment.com
# which provided invaluable help on getting this
# plugin off the ground
# -----------------------------------------------
#
# Copyright for new parts @IkoRein
# 
# Works with the Telemetry Tool from
# https://www.racedepartment.com/downloads/telemetry-tool-for-ac.37231/
#
# -----------------------------------------------

import ac
import acsys
from third_party.ttp_info import *


# Version
VERSION = 1.1
appName = "TELEMETRY TOOL PLUGIN"

# simInfo = SimInfo()

# UDP targets
UDP_IP = "127.0.0.1"
UDP_PORT = 10101

# Constants
NAME_LEN = 33 # max len for car/driver name, same as in Shmem
width, height = 200 , 100 # width and height of the app's window

# VARIABLES
total_drivers = 0

# LABELS
text_drivers = None
text_label = None
counter = 0;

# UDP
socket_to_tool = None

def acMain(ac_version):#----------------------------- App window Init

    # Don't forget to put anything you'll need to update later as a global variables
    #
    global appWindow # <- you'll need to update your window in other functions.
    global UDP_IP
    global UDP_PORT
    #
    # So here we just try to read the config file
    # IF succesful, we will use the values
    # If NOT default values will be used
    #    
    try:
        config = configparser.SafeConfigParser()
        config.read("apps/python/Telemetry_Tool_plugin/config.ini")
        UDP_IP = config.get("telemetry_tool_plugin", "to_ip")
        UDP_PORT = int(config.get("telemetry_tool_plugin", "to_port"))
    except Exception as e:
        ac.console("Telemetry Tool Config Error, file apps/python/Telemetry_Tool_plugin/config.ini not found")

    appWindow = ac.newApp(appName)
    ac.setTitle(appWindow, appName)
    ac.setSize(appWindow, width, height)
    ac.setBackgroundOpacity(appWindow, 0)

    # Variables
    global total_drivers	
    global drivers 
    # LABELS
    global text_drivers
	
    # UDP stuff
    # prepare the sockets
    global socket_to_tool
    socket_to_tool = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # Internet, UDP    

    # get the count of drivers
    total_drivers = ac.getCarsCount() 

    # just a label to get some stuff to app window
    text_label = ac.addLabel(appWindow, "DRIVERS")
    stringDriverNames = "\n\n\nDRIVER NAMES"
    #
    # For the number of active drivers, create a
    # driverInfo for each car
    #
    #for id in range(total_drivers): # find drivers
    #    x,y,z = ac.getCarState(id, acsys.CS.WorldPosition)
    #    speed = ac.getCarState(id, acsys.CS.SpeedMS)		
    #    stringDriverNames += "\n " + ac.getDriverName(id) + " " + ac.getCarName(id) + " " + str(speed) + " " + str(x) + " " + str(y)
	#
    #text_drivers = ac.addLabel(appWindow, stringDriverNames)

    ac.addRenderCallback(appWindow, appGL) # -> links this app's window to an OpenGL render function

    ac.setText(text_label, "\n\nDRIVERS " + str(total_drivers) + "\nPy " + str(platform.python_version()) + "\nPlugin version " + str(VERSION))
    ac.log("Telemetry Tool plugin " + str(VERSION)+ " --- Sending data to " + UDP_IP + ":" + str(UDP_PORT))
    ac.console("Telemetry Tool plugin " + str(VERSION)+ " --- Sending data to " + UDP_IP + ":" + str(UDP_PORT))

    return appName


def appGL(deltaT):#-------------------------------- OpenGL UPDATE
    """
    This is where you redraw your openGL graphics
    if you need to use them .
    """
    pass # -> Delete this line if you do something here !


def acUpdate(deltaT):#-------------------------------- AC UPDATE
    """
    This is where you update your app window ( != OpenGL graphics )
    such as : labels , listener , ect ...
    """
    #VARIABLES
    global total_drivers
    global UDP_IP
    global UDP_PORT
	
    # LABLES
    global text_drivers
    global text_label
	
    # UDP
    global counter    
    global socket_to_tool
	
    total_drivers = ac.getCarsCount()

    #stringDriverNames = "\n\n\nDRIVER NAMES"
    bytes_to_send = struct.pack("<B", 22) #1, adds packet type to the packet for easy detection
    #
    # For the number of active drivers, create a
    # driverInfo for each car, put the data in to a
    # byte array and then send the whole thing out.
    #
    for id in range(total_drivers): # find drivers
        driver_info = DriverInfo(id)
        #x,y,z = ac.getCarState(id, acsys.CS.WorldPosition)
        #speed = ac.getCarState(id, acsys.CS.SpeedKMH)	
        #laptime = ac.getCarState(id, acsys.CS.LapTime)
        #stringDriverNames += "\n " + ac.getDriverName(id) + " " + ac.getCarName(id) + " " + '{:.2f}'.format(speed) + " | " + str(laptime)
        #
        # commented out: sends out individual driverInfo packet
        #socket_to_tool.sendto(getBytesForData(d.id),(UDP_IP, UDP_PORT))
        #
        # add the bytes to the big packet, which gets send at the end
        try :
            bytes_to_send += driver_info.getBytesForTelemetry(False)
        except Exception as e :
            # just log the errors
            ac.log("Telemetry Tool plugin error " + e)
            ac.console("Telemetry Tool plugin " + e)
            # still add the driver id to the top
            bytes_to_send += struct.pack("<I", id)
            # and add 262 '0's to the stream
            bytes_to_send += bytes(262)
        # uncommented out the sending of packet for each driver
        #socket_to_tool.sendto(driver_info.getBytesForTelemetry(),(UDP_IP, UDP_PORT))
    #
    # Sending the set of bytes 
    #
    socket_to_tool.sendto(bytes_to_send,(UDP_IP, UDP_PORT))
    #
    # Send the version info first often, then about once per 10 seconds
    #
    if (counter < 2000 and counter % 200 == 0) or (counter > 2000 and counter % 2000 == 0):
        version_info = VersionInfo()
        version_bytes_to_send = version_info.getBytesForTelemetry()
        socket_to_tool.sendto(version_bytes_to_send,(UDP_IP, UDP_PORT))
    #
    # Keep track of how many times we have sent out the plugin data
    #
    counter += 1
    #
    ac.setText(text_label, "\n\nDRIVERS " + str(total_drivers) + "\nPy " + str(platform.python_version()) + "\nPlugin version " + str(VERSION))
    #
    #

    # END AC UPDATE

def acShutdown():
    # ... If we do UDP connection, we should close it here ...
    return

def getBytesForData( id ) :
    message = str(id) + " " + ac.getDriverName(id)
    return bytes(message, "utf-8")

def clearString (strintToClear , limit) :
    # Take the string, if it is less than limit, 
    # add '\0's to the end of the String (ljust)
    tmp_string = strintToClear
    zeros_to_add = limit - len(tmp_string)
    name_with_zeros = tmp_string.ljust(zeros_to_add + len(tmp_string), '\0') 
    # now return the new string limited to the limit
    # but take the last character away and replace it with
    # '\0', so we can detect the end of the string at the 
    # receiving end. This way the resulting string
    # has length of limit.
    return name_with_zeros[:limit - 1] + '\0' # String


def clearStringSimple(stringToClear, limit):
    # The clearStringSimple function takes the input string and limiter as arguments, 
    # it takes a slice of the input string up to limit-1 and 
    # then pads the string with null characters until it reaches the limit. 
    return stringToClear[:limit-1].ljust(limit, '\0')


class DriverInfo: # class to hold the detailed info for each driver
    def __init__(self, id):
        # need:  sector, (sector from spline at receiving end? Yes)
        # 
        self.id = id # int
        self.test_float = 666.666 # value to test data comes out ok
        self.test_int = 666
        self.lap_time = ac.getCarState(id, acsys.CS.LapTime) #int, milliseconds
        self.last_lap = ac.getCarState(id, acsys.CS.LastLap) #int, milliseconds
        self.best_lap = ac.getCarState(id, acsys.CS.BestLap) # int millisenconds
        #
        # -------------------------
        self.current_splits = ac.getCurrentSplits(id) # array of ints
        self.current_splits_num = len(self.current_splits)
        if self.current_splits_num >= 1:
            self.cur_split1 = self.current_splits[0]
        else :
            self.cur_split1 = -1
        if self.current_splits_num >= 2:
            self.cur_split2 = self.current_splits[1]
        else :
            self.cur_split2 = -1
        if self.current_splits_num >= 3:
            self.cur_split3 = self.current_splits[2]
        else :
            self.cur_split3 = -1
        #
        # -------------------------
        self.last_splits = ac.getLastSplits(id) # array of ints
        self.last_splits_num = len(self.last_splits)
        if self.last_splits_num >= 1:
            self.last_split1 = self.last_splits[0] # int millisenconds
        else:
            self.last_split1 = -1
        if self.last_splits_num >= 2:
            self.last_split2 = self.last_splits[1] # int millisenconds
        else:
            self.last_split2 = -1
        if self.last_splits_num >= 3:
            self.last_split3 = self.last_splits[2]  # int millisenconds
        else:
            self.last_split3 = -1
        # -------------------------
        self.steer = ac.getCarState(id, acsys.CS.Steer) #-2pi ... 2pi
        self.throttle = ac.getCarState(id, acsys.CS.Gas) # float, 0....1
        self.brake = ac.getCarState(id, acsys.CS.Brake) # float 0....1
        self.clutch = ac.getCarState(id, acsys.CS.Clutch)  # float 0....1
        self.gear = ac.getCarState(id, acsys.CS.Gear) # int 
        self.engineRPM  = ac.getCarState(id, acsys.CS.RPM) #int?
        self.speed = 3.6 * ac.getCarState(id, acsys.CS.SpeedMS) # float
        self.track_position = ac.getCarRealTimeLeaderboardPosition(id) # int
        self.leader_board_position = ac.getCarLeaderboardPosition(id) # int
        self.lap_count = ac.getCarState(id, acsys.CS.LapCount) # int
        x,y,z = ac.getCarState(id, acsys.CS.WorldPosition) 
        self.p = [x,y,z]
        self.x = self.p[0] # float
        self.y = self.p[1] # float
        self.z = self.p[2] # float
        self.spline_position = ac.getCarState(id, acsys.CS.NormalizedSplinePosition) # double
        
        #test_name = "1234567890\u532412\u1234\u1234\u1234\u1234\u1234\u1234345678901234567890\65341234567890"
        #self.driver_name = clearStringSimple(test_name, NAME_LEN) # String
        #test_name = ac.getDriverName(id)
        self.driver_name = clearStringSimple(ac.getDriverName(id), NAME_LEN) # String
        #self.driver_name = ac.getDriverName(id)         
        self.nationality = clearStringSimple(ac.getDriverNationCode(id), 4) # int
        #test_name = ac.getCarName(id) # string
        self.car_name = clearStringSimple(ac.getCarName(id), NAME_LEN) # string
        self.tyre_name = clearStringSimple(ac.getCarTyreCompound(id), 10)

        self.is_connected = ac.isConnected(id) # int(byte), 0/1
        self.is_in_pit = ac.isCarInPit(id)  # int(byte), 0/1
        self.is_car_in_pitlane = ac.isCarInPitlane(id)  # int(byte), 0/1
        self.valid = ac.getCarState(id, acsys.CS.LapInvalidated) # int(byte), 0/1

        a,b,c = ac.getCarState(id, acsys.CS.AccG)
        self.acc_g = [a,b,c]
        self.acc_vertical = self.acc_g[0] # float
        self.acc_horizontal = self.acc_g[1] # float
        self.acc_frontal = self.acc_g[2] # flaot

        self.is_engine_limiter_on = ac.getCarState(id, acsys.CS.IsEngineLimiterOn) # int(byte), 0/1
        self.is_drs_available = ac.getCarState(id, acsys.CS.DrsAvailable) # int(byte), 0/1
        self.is_drs_enabled = ac.getCarState(id, acsys.CS.DrsEnabled) # int(byte), 0/1
        self.is_race_finished = ac.getCarState(id, acsys.CS.RaceFinished) # int(byte), 0/1
        self.ptp_status = ac.getCarState(id, acsys.CS.P2PStatus) # int(byte), 
        self.ptp_activations = ac.getCarState(id, acsys.CS.P2PActivations) # int 0 .... n
        self.ers_max_j = ac.getCarState(id, acsys.CS.ERSMaxJ) # float, 4 
        self.ers_current_kj = ac.getCarState(id, acsys.CS.ERSCurrentKJ) # float, 4
        fl, fr, rl, rr = ac.getCarState(id, acsys.CS.TyreDirtyLevel) 
        self.tyre_dirty_level = [fl, fr, rl, rr] # float[4], 0 ....1
        # send up to this point now
        self.turbo_boost = ac.getCarState(id, acsys.CS.TurboBoost) #float
        rhf, rhr = ac.getCarState(id, acsys.CS.RideHeight)
        self.ride_height = [rhf, rhr] # float[2] 
        ccfl, ccfr, ccrl, ccrr = ac.getCarState(id, acsys.CS.CurrentTyresCoreTemp)
        self.current_tyres_core_temp = [ccfl, ccfr, ccrl, ccrr] # float[4]
        #
        # Below removed, could not get it working
        #
        #ttfl, ttfr, ttrl, ttrr = ac.getCarState(id, acsys.CS.LastTyresTemp)
        #a,b,c, d,e,f, g,h,i, j,k,l = ac.getCarState(id, acsys.CS.LastTyresTemp)
        #self.current_tyres_temp = [ttfl, ttfr, ttrl, ttrr] # float[4]



    def getBytesForTelemetry(self, add_type = True):
        # using little endian as that is what the tool is using by default (i.e. Windows default ...)
        if add_type :
            bytes_to_send = struct.pack("<B", 21) #1
            bytes_to_send += struct.pack("<I", self.id) #+ 4
        else :
            bytes_to_send = struct.pack("<I", self.id) #+ 4
        bytes_to_send += struct.pack("<I", self.lap_time) # +4 
        bytes_to_send += struct.pack("<I", self.last_lap) # +4 
        bytes_to_send += struct.pack("<I", self.best_lap) # +4 
        bytes_to_send += struct.pack("<B", self.current_splits_num) #1
        bytes_to_send += struct.pack("<I", self.cur_split1) # +4
        bytes_to_send += struct.pack("<I", self.cur_split2) # +4
        bytes_to_send += struct.pack("<I", self.cur_split3) # +4
        bytes_to_send += struct.pack("<I", self.last_split1) # +4
        bytes_to_send += struct.pack("<I", self.last_split2) # +4
        bytes_to_send += struct.pack("<I", self.last_split3) # +4

        bytes_to_send += struct.pack("<f", self.steer) # +4
        bytes_to_send += struct.pack("<f", self.throttle) # +4
        bytes_to_send += struct.pack("<f", self.brake) # +4
        bytes_to_send += struct.pack("<f", self.clutch) # +4
        bytes_to_send += struct.pack("<h", self.gear) #+2 signed
        bytes_to_send += struct.pack("<f", self.engineRPM) #+ 4
        bytes_to_send += struct.pack("<f", self.speed) #+4

        bytes_to_send += struct.pack("<h", self.track_position) #+2 
        bytes_to_send += struct.pack("<h", self.leader_board_position) # +2
        bytes_to_send += struct.pack("<h", self.lap_count) #+2
        bytes_to_send += struct.pack("<f", self.x) #+4 
        bytes_to_send += struct.pack("<f", self.y) #+4 
        bytes_to_send += struct.pack("<f", self.z) #+4 
        bytes_to_send += struct.pack("<d", self.spline_position) #+8

        bytes_to_send += struct.pack("<f", self.test_float) # +4

        try :
            bytes_to_send += bytes(self.driver_name, "utf-8")[:NAME_LEN-1]+bytes(1) # NAME LEN + 33
            bytes_to_send += bytes(self.nationality, "utf-8") # NAME LEN + 4
            bytes_to_send += bytes(self.car_name, "utf-8")[:NAME_LEN-1]+bytes(1) # NAME LEN + 33
            bytes_to_send += bytes(self.tyre_name, "utf-8") # NAME LEN + 10
        except Exception as e :
            ac.log("Telemetry Tool plugin error: getBytesForTelemetry on strings :" + e)
            bytes_to_send += bytes(80) # 33 + 33 + 10 + 4 = 80

        bytes_to_send += struct.pack("<I", self.test_int) # +4, test value too

        bytes_to_send += struct.pack("<B", self.is_connected) #+1 
        bytes_to_send += struct.pack("<B", self.is_in_pit) #+1 
        bytes_to_send += struct.pack("<B", self.is_car_in_pitlane) #+1 
        bytes_to_send += struct.pack("<B", self.valid) #+1 

        bytes_to_send += struct.pack("<f", self.acc_vertical) # +4
        bytes_to_send += struct.pack("<f", self.acc_horizontal) # +4
        bytes_to_send += struct.pack("<f", self.acc_frontal) # +4

        bytes_to_send += struct.pack("<B", self.is_engine_limiter_on) #+1 
        bytes_to_send += struct.pack("<B", self.is_drs_available) #+1 
        bytes_to_send += struct.pack("<B", self.is_drs_enabled) #+1 
        bytes_to_send += struct.pack("<B", self.is_race_finished) #+1
        bytes_to_send += struct.pack("<B", self.ptp_status) #+1
        bytes_to_send += struct.pack("<I", self.ptp_activations) # +4
        bytes_to_send += struct.pack("<f", self.ers_max_j) #+4
        bytes_to_send += struct.pack("<f", self.ers_current_kj) #+4
        try :
            bytes_to_send += struct.pack("<f", self.tyre_dirty_level[0]) #+4
            bytes_to_send += struct.pack("<f", self.tyre_dirty_level[1]) #+4
            bytes_to_send += struct.pack("<f", self.tyre_dirty_level[2]) #+4
            bytes_to_send += struct.pack("<f", self.tyre_dirty_level[3]) #+4
            bytes_to_send += struct.pack("<f", self.turbo_boost) #+4
            bytes_to_send += struct.pack("<f", self.ride_height[0]) # +4
            bytes_to_send += struct.pack("<f", self.ride_height[1]) # +4
            bytes_to_send += struct.pack("<f", self.current_tyres_core_temp[0]) # +4
            bytes_to_send += struct.pack("<f", self.current_tyres_core_temp[1]) # +4
            bytes_to_send += struct.pack("<f", self.current_tyres_core_temp[2]) # +4
            bytes_to_send += struct.pack("<f", self.current_tyres_core_temp[3]) # +4
        except Exception as e :
            ac.log("Telemetry Tool plugin error: getBytesForTelemetry on arrays :" + e)
            bytes_to_send += bytes(24)
        # send this as last item, helps to check the struct comes in correctly
        bytes_to_send += struct.pack("<d", self.test_float) # +8, send out as double!
        return bytes_to_send

class VersionInfo: # class to hold the plugin version, gets send every 100 packets.
    def __init__(self):
        # 
        self.version = VERSION # float
        self.test_float = 666.666 # value to test data comes out ok
        
    def getBytesForTelemetry(self):
        # using little endian as that is what the tool is using by default (i.e. Windows default ...)
        bytes_to_send = struct.pack("<B", 23) #1, id 23 is for version packets
        bytes_to_send += struct.pack("<f", self.version) # +4        
        return bytes_to_send
