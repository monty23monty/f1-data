"""
Original sim_info.py by >>> Rombik <<<

I didn't change much here , beside ctypes import.
    -Hunter Vaners-
"""

import mmap
import functools

# ------------------------------------


# To import ctypes , we need to see if the system is 64 or 32 bits

import platform
import os
import sys

if platform.architecture()[0] == "64bit":
    libdir = 'lib64'
else:
    libdir = 'lib'
sys.path.insert(0, os.path.join(os.path.dirname(__file__), libdir))
os.environ['PATH'] = os.environ['PATH'] + ";."

import socket
import ssl
import struct

import ctypes

import configparser

# ------------------------------------

